<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::rename('enquiries', 'enquiry');

        Schema::table('enquiry', function (Blueprint $table) {
            $table->tinyInteger('status')->default(1)->after('current_followup_date');
        });

        DB::statement('ALTER TABLE enquiry MODIFY COLUMN log_status TINYINT NOT NULL DEFAULT 1 AFTER status');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        DB::statement('ALTER TABLE enquiry MODIFY COLUMN log_status TINYINT NOT NULL DEFAULT 1 AFTER enquiry_no');

        Schema::table('enquiry', function (Blueprint $table) {
            $table->dropColumn('status');
        });

        Schema::rename('enquiry', 'enquiries');
    }
};
